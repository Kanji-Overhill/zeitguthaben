<?php
/**
 * File: 
 *  theme-functions/scripts.php 
 * 
 * This file contains all the JavaScript files needed for the theme.
 * 
 */





