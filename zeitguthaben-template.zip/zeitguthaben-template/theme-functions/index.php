<?php 

// Require all external libraries (CSS & JS files)
require_once __DIR__ . '/lib.php';

// Require all CSS files
require_once __DIR__ . '/styles.php';

